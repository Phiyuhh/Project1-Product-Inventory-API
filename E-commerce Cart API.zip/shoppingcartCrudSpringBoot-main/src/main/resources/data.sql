insert into product (id,name,available_quantity,price) values
(1,'laptop',5,45900),
(2,'mobile',10,7999),
(3,'smart watch',6,2999);